from django.apps import AppConfig


class Podcastbird657Config(AppConfig):
    name = 'podcastbird657'
